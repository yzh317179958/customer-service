import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';

const FAQItem: React.FC<{ question: string; answer: string }> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="border-b border-slate-800">
      <button 
        className="w-full py-6 flex items-center justify-between text-left focus:outline-none group"
        onClick={() => setIsOpen(!isOpen)}
      >
        <span className="text-lg font-medium text-slate-200 group-hover:text-brand-400 transition-colors">{question}</span>
        {isOpen ? <ChevronUp className="h-5 w-5 text-brand-400" /> : <ChevronDown className="h-5 w-5 text-slate-400 group-hover:text-white" />}
      </button>
      <div 
        className={`overflow-hidden transition-all duration-300 ${isOpen ? 'max-h-48 opacity-100 pb-6' : 'max-h-0 opacity-0'}`}
      >
        <p className="text-slate-400 leading-relaxed">
          {answer}
        </p>
      </div>
    </div>
  );
};

const FAQ: React.FC = () => {
  const faqs = [
    {
      question: "NovaStream 如何保障数据安全？",
      answer: "我们采用 AES-256 静态加密和 TLS 1.3 传输加密。平台已通过 SOC2 Type II 认证，并定期进行第三方安全审计，确保您的数据万无一失。"
    },
    {
      question: "我可以部署在自己的私有基础设施上吗？",
      answer: "可以。我们的企业版支持通过 Docker 容器或 Kubernetes Helm Charts 进行混合云和私有化部署，满足您的合规需求。"
    },
    {
      question: "专业版提供免费试用吗？",
      answer: "当然。您可以免费试用专业版 14 天，无需绑定信用卡。我们希望您在充分体验 NovaStream 的强大功能后再做决定。"
    },
    {
      question: "你们支持哪些集成？",
      answer: "我们支持超过 200 种数据源和目的地，包括 Postgres, Snowflake, MongoDB, BigQuery, Salesforce 和 HubSpot 等主流平台。"
    }
  ];

  return (
    <section id="faq" className="py-24">
      <div className="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8">
        <h2 className="text-3xl md:text-4xl font-bold text-white mb-12 text-center">
          常见问题解答
        </h2>
        <div className="space-y-2">
          {faqs.map((faq, i) => (
            <FAQItem key={i} {...faq} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default FAQ;