import React, { useState } from 'react';
import { Check, Zap, Bot, BarChart, Sparkles } from 'lucide-react';
import Button from './ui/Button';

export const PRICING_PLANS = [
  {
    id: "starter",
    name: "Starter 启航版",
    productFocus: "业务数字化起步",
    icon: <Bot className="w-6 h-6" />,
    priceMonthly: 199,
    priceYearly: 159,
    desc: "适合初创品牌。利用 AI 快速打通基础客服细节，确保 24/7 业务不掉线。",
    features: [
      "全天候基础咨询自动化 (2k/月)",
      "订单 & 物流实时同步查询",
      "Shopify 全量商品知识同步",
      "50+ 语种自动识别与回复",
      "基础业务转化率监控看板",
      "标准品牌语调配置"
    ],
    recommended: false
  },
  {
    id: "pro",
    name: "Professional 专业版",
    productFocus: "全链路增长引擎",
    icon: <Zap className="w-6 h-6" />,
    priceMonthly: 599,
    priceYearly: 479,
    recommended: true,
    desc: "适合成长期品牌。深度绑定业务流，从售前转化到售后履约实现全链路 AI 化。",
    features: [
      "高意向询盘 AI 转化引导 (10k/月)",
      "售后争议全自动工单闭环",
      "AI 辅助人工提效建议 (300%+)",
      "弃单召回自动化营销模块",
      "深度业务 ROI 洞察大盘",
      "自定义品牌专属知识中枢",
      "多渠道会话聚合管理"
    ]
  },
  {
    id: "enterprise",
    name: "Enterprise 旗舰版",
    productFocus: "品牌 AI 战略伙伴",
    icon: <BarChart className="w-6 h-6" />,
    priceMonthly: "Custom",
    priceYearly: "Custom",
    desc: "适合大卖家及全球品牌。私有化深度定制，作为企业 AI 操作系统支撑全球转型。",
    features: [
      "专属私有化模型训练 (品牌微调)",
      "全域 API 深度业务集成 & 读写",
      "1:1 品牌 AI 转型增长顾问",
      "无限坐席 & 无限会话规模",
      "SLA 99.9% 业务连续性保障",
      "SOC2 / GDPR 全球合规安全包",
      "定制化 UI/UX 品牌一致性方案"
    ]
  }
];

const PricingCard: React.FC<{
  plan: typeof PRICING_PLANS[0];
  period: 'monthly' | 'yearly';
}> = ({ plan, period }) => {
  const price = period === 'monthly' ? plan.priceMonthly : plan.priceYearly;
  
  return (
    <div className={`relative p-8 md:p-10 rounded-[3.5rem] flex flex-col h-full transition-all duration-700 border-2
      ${plan.recommended 
        ? 'bg-white text-text-primary shadow-[0_40px_100px_-20px_rgba(79,70,229,0.12)] border-brand-600 scale-105 z-10' 
        : 'bg-white text-text-primary border-bg-200 hover:border-brand-200 shadow-sm'
      }
    `}>
      {plan.recommended && (
        <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-brand-600 text-white text-[10px] font-black uppercase tracking-widest rounded-full shadow-lg flex items-center gap-2">
          <Sparkles size={10} /> Brand Choice
        </div>
      )}
      
      <div className="mb-10">
        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-6 ${plan.recommended ? 'bg-brand-600 text-white' : 'bg-brand-50 text-brand-600'} shadow-md`}>
            {plan.icon}
        </div>
        <div className="text-[10px] font-black uppercase tracking-[0.2em] mb-2 text-brand-600">
            {plan.productFocus}
        </div>
        <h3 className="text-2xl font-black mb-3">{plan.name}</h3>
        <p className="text-xs leading-relaxed text-text-secondary font-medium h-12">{plan.desc}</p>
        
        <div className="mt-8 flex items-baseline gap-1">
          {typeof price === 'number' ? (
            <>
              <span className="text-2xl font-bold">$</span>
              <span className="text-6xl font-black tracking-tighter">{price}</span>
              <span className="text-sm text-text-muted font-bold ml-1">/mo</span>
            </>
          ) : (
            <span className="text-4xl font-black text-text-primary">{price}</span>
          )}
        </div>
      </div>

      <ul className="space-y-4 mb-12 flex-grow">
        {plan.features.map((feat, i) => (
          <li key={i} className="flex items-start gap-3 text-sm font-medium">
            <Check className="h-4 w-4 shrink-0 mt-0.5 text-brand-600" />
            <span className="text-text-secondary">{feat}</span>
          </li>
        ))}
      </ul>

      <Button 
        variant={plan.recommended ? 'primary' : 'secondary'} 
        className={`w-full h-16 font-black shadow-lg ${plan.recommended ? 'shadow-brand-600/30' : ''}`}
        withArrow={plan.recommended}
      >
        {typeof price === 'string' ? '咨询深度绑定方案' : '开启 14 天免费 AI 转型之旅'}
      </Button>
    </div>
  );
};

const Pricing: React.FC = () => {
  const [billingCycle, setBillingCycle] = useState<'monthly' | 'yearly'>('yearly');

  return (
    <section id="pricing" className="py-32 bg-bg-50 relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        <div className="text-center max-w-3xl mx-auto mb-24">
          <h2 className="text-4xl md:text-5xl font-black text-text-primary mb-8 tracking-tight">业务驱动的透明定价</h2>
          <p className="text-text-secondary text-lg mb-10 font-medium">所有的增长引擎都支持深度业务逻辑绑定，确保 AI 为您的品牌量身定制。</p>
          
          <div className="inline-flex bg-white p-1.5 rounded-full border border-bg-200 shadow-sm relative">
            <button 
              onClick={() => setBillingCycle('monthly')}
              className={`relative z-10 px-10 py-3 rounded-full text-sm font-black transition-all ${billingCycle === 'monthly' ? 'bg-brand-600 text-white shadow-md' : 'text-text-muted hover:text-text-primary'}`}
            >
              按月支付
            </button>
            <button 
              onClick={() => setBillingCycle('yearly')}
              className={`relative z-10 px-10 py-3 rounded-full text-sm font-black transition-all flex items-center gap-2 ${billingCycle === 'yearly' ? 'bg-brand-600 text-white shadow-md' : 'text-text-muted hover:text-text-primary'}`}
            >
              按年支付 <span className="text-[9px] px-1.5 py-0.5 bg-brand-100 text-brand-700 rounded-md font-bold">-20%</span>
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 items-stretch max-w-6xl mx-auto">
          {PRICING_PLANS.map(plan => (
            <PricingCard key={plan.id} plan={plan} period={billingCycle} />
          ))}
        </div>
        
        <div className="mt-20 text-center">
           <p className="text-sm font-bold text-text-muted flex items-center justify-center gap-2">
              <Sparkles size={14} className="text-brand-600" />
              所有方案均提供免费的品牌转型对标诊断与数据迁移服务
           </p>
        </div>
      </div>
    </section>
  );
};

export default Pricing;